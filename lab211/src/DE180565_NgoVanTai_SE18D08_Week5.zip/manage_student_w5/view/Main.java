package manage_student_w5.view;

import manage_student_w5.controller.ConsoleForm;

public class Main {

    public static void main(String[] args) {
        ConsoleForm consoleForm=new ConsoleForm();
        consoleForm.execute();
    }
}
