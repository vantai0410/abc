package ManageWorkerInformation;

import ManageWorkerInformation.Controller.WorkerController;
import ManageWorkerInformation.Model.WorkerList;
import ManageWorkerInformation.View.WorkerView;

public class Main {
    public static void main(String[] args) {
        WorkerList workerList = new WorkerList();
        WorkerView workerView = new WorkerView();
        WorkerController controller = new WorkerController(workerList,workerView);
        controller.run();;
    }
}
